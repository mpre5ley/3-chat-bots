# Maps URLs for each Django application

from django.urls import path, include
from django.contrib.auth import views as auth_views


urlpatterns = [
    path("", include("chat.urls")),
    path("accounts/login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("accounts/logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("accounts/", include("django.contrib.auth.urls")),
]
